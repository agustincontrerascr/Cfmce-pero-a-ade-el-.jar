package com.mrcrayfish.furniturece.tileentity;

import net.minecraft.item.ItemBook;
import net.minecraft.item.ItemEditableBook;
import net.minecraft.item.ItemEnchantedBook;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemWritableBook;

public class TileEntityBookShelf extends BasicInventory
{
	public TileEntityBookShelf()
	{
		super(5);
	}

	public int getBookCount()
	{
		int count = 0;
		for (int i = 0; i < getSizeInventory(); i++)
		{
			if (!getStackInSlot(i).isEmpty())
			{
				count++;
			}
		}
		return count;
	}

	@Override
	public boolean isItemValidForSlot(int index, ItemStack stack)
	{
		return stack.getItem() instanceof ItemBook || stack.getItem() instanceof ItemWritableBook || stack.getItem() instanceof ItemEnchantedBook || stack.getItem() instanceof ItemEditableBook;
	}
}
