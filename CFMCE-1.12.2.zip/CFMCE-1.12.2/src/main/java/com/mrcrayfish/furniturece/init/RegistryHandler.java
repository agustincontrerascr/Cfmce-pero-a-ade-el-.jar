package com.mrcrayfish.furniturece.init;

import com.mrcrayfish.furniturece.CESoundEvents;
import com.mrcrayfish.furniturece.Reference;

import net.minecraft.block.Block;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = Reference.MOD_ID)
public class RegistryHandler
{
	@SubscribeEvent
	public static void registerBlocks(RegistryEvent.Register<Block> event)
	{
		FurnitureBlocks.init();
		FurnitureBlocks.register(event.getRegistry());
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event)
	{
		FurnitureItems.init();
		FurnitureItems.register(event.getRegistry());
		FurnitureBlocks.registerItems(event.getRegistry());
	}

	@SubscribeEvent
	public static void registerSounds(RegistryEvent.Register<SoundEvent> event)
	{
		CESoundEvents.init();
		event.getRegistry().register(CESoundEvents.bear);
	}

	@Mod.EventBusSubscriber(modid = Reference.MOD_ID, value = Side.CLIENT)
	public static class Models
	{
		@SubscribeEvent
		public static void registerModels(ModelRegistryEvent event)
		{
			for (Block block : FurnitureBlocks.all())
			{
				registerModel(Item.getItemFromBlock(block));
			}
			registerModel(FurnitureItems.info_pencil);
			registerModel(FurnitureItems.easter_egg);
		}

		private static void registerModel(Item item)
		{
			ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
		}
	}
}
