package com.mrcrayfish.furniturece.block;

import com.mrcrayfish.furniturece.Reference;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;

public class BlockBookStack extends BlockFurnitureOffice
{
	public BlockBookStack(Material materialIn)
	{
		super(materialIn);
		setUnlocalizedName("book_stack");
		setRegistryName(Reference.MOD_ID, "book_stack");
	}

	@Override
	protected AxisAlignedBB getBounds(IBlockState state)
	{
		return new AxisAlignedBB(0F, 0F, 0F, 1F, 8 * 0.0625F, 1F);
	}

	@Override
	public String getAuthorName()
	{
		return "MickeyAnimations";
	}

	@Override
	public int getAuthorID()
	{
		return 964;
	}

	@Override
	public String getTheme()
	{
		return Reference.THEME_OFFICE;
	}
}
