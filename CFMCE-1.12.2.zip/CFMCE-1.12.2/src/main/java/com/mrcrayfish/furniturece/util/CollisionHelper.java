package com.mrcrayfish.furniturece.util;

import net.minecraft.util.math.AxisAlignedBB;

public class CollisionHelper
{
	/** Rotates a box (given in "north" orientation) by the horizontal index of the facing. */
	public static AxisAlignedBB rotated(int metadata, float x1, float y1, float z1, float x2, float y2, float z2)
	{
		float[] b = fixRotation(metadata, x1, z1, x2, z2);
		return new AxisAlignedBB(b[0], y1, b[1], b[2], y2, b[3]);
	}

	public static float[] fixRotation(int metadata, float var1, float var2, float var3, float var4)
	{
		switch (metadata)
		{
		case 1:
			float var_temp_1 = var1;
			var1 = 1.0F - var3;
			float var_temp_2 = var2;
			var2 = 1.0F - var4;
			var3 = 1.0F - var_temp_1;
			var4 = 1.0F - var_temp_2;
			break;
		case 2:
			float var_temp_3 = var1;
			var1 = var2;
			var2 = 1.0F - var3;
			var3 = var4;
			var4 = 1.0F - var_temp_3;
			break;
		case 0:
			float var_temp_4 = var1;
			var1 = 1.0F - var4;
			float var_temp_5 = var2;
			var2 = var_temp_4;
			float var_temp_6 = var3;
			var3 = 1.0F - var_temp_5;
			var4 = var_temp_6;
			break;
		}
		return new float[] { var1, var2, var3, var4 };
	}
}
