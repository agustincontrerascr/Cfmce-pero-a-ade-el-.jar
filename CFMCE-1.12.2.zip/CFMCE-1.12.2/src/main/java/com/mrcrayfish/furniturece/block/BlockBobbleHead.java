package com.mrcrayfish.furniturece.block;

import com.mrcrayfish.furniturece.Reference;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;

public class BlockBobbleHead extends BlockFurnitureOffice
{
	public BlockBobbleHead(Material materialIn)
	{
		super(materialIn);
		setUnlocalizedName("bobble_head");
		setRegistryName(Reference.MOD_ID, "bobble_head");
	}

	@Override
	protected AxisAlignedBB getBounds(IBlockState state)
	{
		return new AxisAlignedBB(3 * 0.0625F, 0F, 3 * 0.0625F, 13 * 0.0625F, 18 * 0.0625F, 13 * 0.0625F);
	}

	@Override
	protected AxisAlignedBB getCollisionBounds(IBlockState state)
	{
		return new AxisAlignedBB(4 * 0.0625F, 0F, 4 * 0.0625F, 12 * 0.0625F, 17 * 0.0625F, 12 * 0.0625F);
	}

	@Override
	public String getAuthorName()
	{
		return "datcrazedtitan";
	}

	@Override
	public int getAuthorID()
	{
		return 1082;
	}

	@Override
	public String getTheme()
	{
		return Reference.THEME_OFFICE;
	}
}
