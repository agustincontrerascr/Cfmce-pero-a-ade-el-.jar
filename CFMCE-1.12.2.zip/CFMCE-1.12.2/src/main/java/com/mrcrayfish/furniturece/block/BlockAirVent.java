package com.mrcrayfish.furniturece.block;

import com.mrcrayfish.furniturece.Reference;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import com.mrcrayfish.furniturece.tileentity.TileEntityAirVent;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;

public class BlockAirVent extends BlockFurnitureOffice implements ITileEntityProvider
{
	public BlockAirVent(Material materialIn)
	{
		super(materialIn);
		setUnlocalizedName("air_vent");
		setRegistryName(Reference.MOD_ID, "air_vent");
	}

	@Override
	protected AxisAlignedBB getBounds(IBlockState state)
	{
		return com.mrcrayfish.furniturece.util.CollisionHelper.rotated(metaOf(state), 14 * 0.0625F, 0F, 0F, 1F, 1F, 1F);
	}

	@Override
	protected AxisAlignedBB getCollisionBounds(IBlockState state)
	{
		return com.mrcrayfish.furniturece.util.CollisionHelper.rotated(metaOf(state), 15 * 0.0625F, 0F, 0F, 1F, 1F, 1F);
	}

	@Override
	public TileEntity createNewTileEntity(World worldIn, int meta)
	{
		return new TileEntityAirVent();
	}

	@Override
	public String getAuthorName()
	{
		return "Oravaliito";
	}

	@Override
	public int getAuthorID()
	{
		return 1013;
	}

	@Override
	public String getTheme()
	{
		return Reference.THEME_OFFICE;
	}
}
