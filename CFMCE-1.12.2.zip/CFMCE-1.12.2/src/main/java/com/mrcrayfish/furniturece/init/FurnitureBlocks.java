package com.mrcrayfish.furniturece.init;

import com.mrcrayfish.furniturece.block.*;
import com.mrcrayfish.furniturece.item.ItemFurniture;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraftforge.registries.IForgeRegistry;

public class FurnitureBlocks
{
	public static BlockAquarium aquarium;
	public static BlockCanvas canvas;
	public static BlockChimney chimney;
	public static BlockSpiralStairs spiral_stairs;
	public static BlockBearRug bear_rug;
	public static BlockBlackBoard black_board;
	public static BlockOfficeChair office_chair;
	public static BlockGreenWheelieBin green_wheelie_bin;
	public static BlockCoffeeTable coffee_table;
	public static BlockBottle bottle;
	public static BlockWaterCooler cooler;
	public static BlockBookStack book_stack;
	public static BlockCeilingFan ceiling_fan;
	public static BlockBookShelf book_shelf;
	public static BlockMicrophone microphone;
	public static BlockAirVent air_vent;
	public static BlockCoffeeMachine coffee_machine;
	public static Block3DPrinter three_dimension_printer;
	public static BlockBobbleHead bobble_head;
	public static BlockCorkBoard cork_board;

	public static void init()
	{
		aquarium = new BlockAquarium(Material.GLASS);
		canvas = new BlockCanvas(Material.WOOD);
		chimney = new BlockChimney(Material.ROCK);
		spiral_stairs = new BlockSpiralStairs(Material.WOOD);
		bear_rug = new BlockBearRug(Material.CLOTH);
		black_board = new BlockBlackBoard(Material.WOOD);
		office_chair = new BlockOfficeChair(Material.CLAY);
		green_wheelie_bin = new BlockGreenWheelieBin(Material.WOOD);
		coffee_table = new BlockCoffeeTable(Material.WOOD);
		bottle = new BlockBottle(Material.GLASS);
		cooler = new BlockWaterCooler(Material.ROCK);
		book_stack = new BlockBookStack(Material.CLOTH);
		ceiling_fan = new BlockCeilingFan(Material.WOOD);
		book_shelf = new BlockBookShelf(Material.WOOD);
		microphone = new BlockMicrophone(Material.WOOD);
		air_vent = new BlockAirVent(Material.WOOD);
		coffee_machine = new BlockCoffeeMachine(Material.WOOD);
		three_dimension_printer = new Block3DPrinter(Material.WOOD);
		bobble_head = new BlockBobbleHead(Material.WOOD);
		cork_board = new BlockCorkBoard(Material.WOOD);
	}

	public static void register(IForgeRegistry<Block> registry)
	{
		registry.register(aquarium);
		registry.register(canvas);
		registry.register(chimney);
		registry.register(spiral_stairs);
		registry.register(bear_rug);
		registry.register(black_board);
		registry.register(office_chair);
		registry.register(green_wheelie_bin);
		registry.register(coffee_table);
		registry.register(bottle);
		registry.register(cooler);
		registry.register(book_stack);
		registry.register(ceiling_fan);
		registry.register(book_shelf);
		registry.register(microphone);
		registry.register(air_vent);
		registry.register(coffee_machine);
		registry.register(three_dimension_printer);
		registry.register(bobble_head);
		registry.register(cork_board);
	}

	public static void registerItems(IForgeRegistry<Item> registry)
	{
		registry.register(new ItemFurniture(aquarium).setRegistryName(aquarium.getRegistryName()));
		registry.register(new ItemFurniture(canvas).setRegistryName(canvas.getRegistryName()));
		registry.register(new ItemFurniture(chimney).setRegistryName(chimney.getRegistryName()));
		registry.register(new ItemFurniture(spiral_stairs).setRegistryName(spiral_stairs.getRegistryName()));
		registry.register(new ItemFurniture(bear_rug).setRegistryName(bear_rug.getRegistryName()));
		registry.register(new ItemFurniture(black_board).setRegistryName(black_board.getRegistryName()));
		registry.register(new ItemFurniture(office_chair).setRegistryName(office_chair.getRegistryName()));
		registry.register(new ItemFurniture(green_wheelie_bin).setRegistryName(green_wheelie_bin.getRegistryName()));
		registry.register(new ItemFurniture(coffee_table).setRegistryName(coffee_table.getRegistryName()));
		registry.register(new ItemFurniture(bottle).setRegistryName(bottle.getRegistryName()));
		registry.register(new ItemFurniture(cooler).setRegistryName(cooler.getRegistryName()));
		registry.register(new ItemFurniture(book_stack).setRegistryName(book_stack.getRegistryName()));
		registry.register(new ItemFurniture(ceiling_fan).setRegistryName(ceiling_fan.getRegistryName()));
		registry.register(new ItemFurniture(book_shelf).setRegistryName(book_shelf.getRegistryName()));
		registry.register(new ItemFurniture(microphone).setRegistryName(microphone.getRegistryName()));
		registry.register(new ItemFurniture(air_vent).setRegistryName(air_vent.getRegistryName()));
		registry.register(new ItemFurniture(coffee_machine).setRegistryName(coffee_machine.getRegistryName()));
		registry.register(new ItemFurniture(three_dimension_printer).setRegistryName(three_dimension_printer.getRegistryName()));
		registry.register(new ItemFurniture(bobble_head).setRegistryName(bobble_head.getRegistryName()));
		registry.register(new ItemFurniture(cork_board).setRegistryName(cork_board.getRegistryName()));
	}

	public static Block[] all()
	{
		return new Block[] { aquarium, canvas, chimney, spiral_stairs, bear_rug, black_board, office_chair, green_wheelie_bin, coffee_table, bottle, cooler, book_stack, ceiling_fan, book_shelf, microphone, air_vent, coffee_machine, three_dimension_printer, bobble_head, cork_board };
	}
}
