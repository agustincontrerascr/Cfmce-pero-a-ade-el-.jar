package com.mrcrayfish.furniturece.tileentity;

import javax.annotation.Nullable;

import net.minecraft.block.state.IBlockState;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;

public class TileEntityWaterCooler extends TileEntity
{
	private int waterLevel;

	private void sync()
	{
		markDirty();
		if (world != null)
		{
			IBlockState state = world.getBlockState(pos);
			world.notifyBlockUpdate(pos, state, state, 3);
		}
	}

	public boolean addWater()
	{
		if (waterLevel < 32)
		{
			waterLevel++;
			sync();
			return true;
		}
		return false;
	}

	public boolean removeWater()
	{
		if (waterLevel > 0)
		{
			waterLevel--;
			sync();
			return true;
		}
		return false;
	}

	public int getWaterLevel()
	{
		return waterLevel;
	}

	public float getWaterLevelPercentage()
	{
		return waterLevel / 32F;
	}

	@Override
	public void readFromNBT(NBTTagCompound compound)
	{
		super.readFromNBT(compound);
		this.waterLevel = compound.getInteger("WaterLevel");
	}

	@Override
	public NBTTagCompound writeToNBT(NBTTagCompound compound)
	{
		super.writeToNBT(compound);
		compound.setInteger("WaterLevel", this.waterLevel);
		return compound;
	}

	@Override
	public NBTTagCompound getUpdateTag()
	{
		return this.writeToNBT(new NBTTagCompound());
	}

	@Nullable
	@Override
	public SPacketUpdateTileEntity getUpdatePacket()
	{
		return new SPacketUpdateTileEntity(this.pos, 0, this.getUpdateTag());
	}

	@Override
	public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt)
	{
		this.readFromNBT(pkt.getNbtCompound());
	}
}
