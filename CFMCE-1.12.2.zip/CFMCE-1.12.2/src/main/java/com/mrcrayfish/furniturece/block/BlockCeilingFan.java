package com.mrcrayfish.furniturece.block;

import com.mrcrayfish.furniturece.MrCrayfishFurnitureModCE;
import com.mrcrayfish.furniturece.Reference;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockCeilingFan extends Block implements IModelInfo
{
	public BlockCeilingFan(Material materialIn)
	{
		super(materialIn);
		setUnlocalizedName("ceiling_fan");
		setRegistryName(Reference.MOD_ID, "ceiling_fan");
		setCreativeTab(MrCrayfishFurnitureModCE.tabFurniture);
		setHardness(0.5F);
	}

	@Override
	public boolean isOpaqueCube(IBlockState state)
	{
		return false;
	}

	@Override
	public boolean isFullCube(IBlockState state)
	{
		return false;
	}

	@Override
	public BlockFaceShape getBlockFaceShape(IBlockAccess world, IBlockState state, BlockPos pos, EnumFacing face)
	{
		return BlockFaceShape.UNDEFINED;
	}

	@SideOnly(Side.CLIENT)
	@Override
	public BlockRenderLayer getBlockLayer()
	{
		return BlockRenderLayer.CUTOUT;
	}

	@Override
	public String getAuthorName()
	{
		return "blackdragon6547";
	}

	@Override
	public int getAuthorID()
	{
		return 615;
	}

	@Override
	public String getTheme()
	{
		return Reference.THEME_OFFICE;
	}
}
