package com.mrcrayfish.furniturece.item;

import java.util.List;

import net.minecraft.util.text.TextFormatting;
import com.mrcrayfish.furniturece.block.IModelInfo;

import net.minecraft.block.Block;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemFurniture extends ItemBlock
{
	public ItemFurniture(Block block)
	{
		super(block);
	}
	
	@Override
	public void addInformation(ItemStack stack, @javax.annotation.Nullable World worldIn, List<String> tooltip, net.minecraft.client.util.ITooltipFlag flagIn)
	{
		if(this.block instanceof IModelInfo)
		{
			IModelInfo info = (IModelInfo) this.block;
			tooltip.add(TextFormatting.BLUE + "Model Designed By:");
			tooltip.add(TextFormatting.GOLD + info.getAuthorName());
		}
	}
}
