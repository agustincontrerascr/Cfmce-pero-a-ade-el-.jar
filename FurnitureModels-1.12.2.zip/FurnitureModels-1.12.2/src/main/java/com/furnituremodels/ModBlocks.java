package com.furnituremodels;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.block.Block;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(modid = FurnitureMod.MODID)
public class ModBlocks {
    private static final Map<String, Block> BLOCKS = new LinkedHashMap<>();

    static {
        add("air_vent", 0.0625, 0.0625, 0.0, 0.9375, 0.9375, 0.0625, false);
        add("aquarium", 0.0, 0.0, 0.0, 1.0, 0.625, 1.0, true);
        add("bear_rug", 0.0, 0.0, 0.0625, 1.0, 0.3125, 1.0, false);
        add("black_board", 0.0, 0.0, 0.0, 1.0, 1.0, 0.5, false);
        add("bobble_head", 0.25, 0.0, 0.3125, 0.75, 1.0, 0.6875, false);
        add("book_shelf", 0.0, 0.0, 0.0, 1.0, 0.85, 0.5312, false);
        add("book_stack", 0.0, 0.0, 0.1875, 0.8125, 0.625, 0.875, false);
        add("bottle", 0.1875, 0.0, 0.1875, 0.875, 1.0, 0.8711, true);
        add("canvas", 0.0625, 0.0, 0.125, 0.9375, 1.0, 0.575, false);
        add("ceiling_fan", 0.0, 0.0312, 0.3312, 1.0, 1.0, 0.6687, false);
        add("chimney", 0.0, 0.0, 0.0, 1.0, 1.0, 0.8812, false);
        add("coffee_machine", 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, false);
        add("coffee_table", 0.0, 0.0, 0.0, 1.0, 0.625, 1.0, true);
        add("cooler", 0.1875, 0.0, 0.1875, 0.8125, 1.0, 0.8125, true);
        add("cork_board", 0.0, 0.0, 0.0, 1.0, 1.0, 0.125, false);
        add("green_wheelie_bin", 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, false);
        add("microphone", 0.25, 0.0, 0.25, 0.75, 1.0, 0.75, false);
        add("office_chair", 0.0, 0.0, 0.0938, 1.0, 1.0, 0.9062, false);
        add("spiral_stairs", 0.0, 0.0, 0.0625, 1.0, 0.9999, 1.0, false);
        add("three_dimension_printer", 0.0, 0.0, 0.0, 1.0, 0.8125, 0.9375, false);
    }

    private static void add(String name, double x0, double y0, double z0,
                            double x1, double y1, double z1, boolean translucent) {
        BLOCKS.put(name, new FurnitureBlock(name, x0, y0, z0, x1, y1, z1, translucent));
    }

    public static Block get(String name) {
        return BLOCKS.get(name);
    }

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> event) {
        for (Block b : BLOCKS.values()) event.getRegistry().register(b);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        for (Block b : BLOCKS.values()) {
            Item item = new ItemBlock(b);
            item.setRegistryName(b.getRegistryName());
            event.getRegistry().register(item);
        }
    }

    @Mod.EventBusSubscriber(modid = FurnitureMod.MODID, value = Side.CLIENT)
    public static class Client {
        @SubscribeEvent
        public static void registerModels(ModelRegistryEvent event) {
            for (Block b : BLOCKS.values()) {
                ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(b), 0,
                        new ModelResourceLocation(b.getRegistryName(), "inventory"));
            }
        }
    }
}
