package com.furnituremodels;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;

@Mod(modid = FurnitureMod.MODID, name = "Furniture Models", version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
public class FurnitureMod {
    public static final String MODID = "furnituremodels";

    public static final CreativeTabs TAB = new CreativeTabs(MODID) {
        @Override
        public ItemStack getTabIconItem() {
            return new ItemStack(ModBlocks.get("office_chair"));
        }
    };
}
