@echo off
echo === Furniture Models 1.12.2 - construyendo el .jar ===
echo Necesitas Java JDK 8 instalado (no el 17/21) y conexion a internet.
java -version
call gradlew.bat build
echo.
echo Si todo salio bien, tu mod esta en: build\libs\FurnitureModels-1.0.jar
echo Copialo a la carpeta mods de Minecraft 1.12.2 con Forge.
pause
