@echo off
REM === Compila el mod y deja el .jar en la carpeta "JAR" ===
REM Necesita JDK 8 e internet (solo la primera vez, baja Forge).
REM Si tienes MCreator instalado, pon aqui la ruta de su carpeta "jdk", por ejemplo:
REM set "JAVA_HOME=C:\Program Files\MCreator\jdk"
REM (si no, usa el Java 8 que tengas instalado)

if defined JAVA_HOME set "PATH=%JAVA_HOME%\bin;%PATH%"
java -version
if errorlevel 1 (
  echo.
  echo No se encontro Java. Instala JDK 8 o edita JAVA_HOME en este archivo.
  pause
  exit /b 1
)

call gradlew.bat build
if errorlevel 1 (
  echo.
  echo Error al compilar. Copia el mensaje de arriba y mandamelo.
  pause
  exit /b 1
)

if not exist JAR mkdir JAR
copy /Y build\libs\*.jar JAR\
echo.
echo Listo. El .jar esta en la carpeta JAR. Copialo a .minecraft\mods
pause
